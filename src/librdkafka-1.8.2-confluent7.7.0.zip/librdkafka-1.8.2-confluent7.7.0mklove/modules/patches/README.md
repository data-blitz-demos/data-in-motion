This directory contains patches to dependencies used by the source installers in configure.*


Patch filename format is:
<module>.NNNN-description_of_patch.patch

Where module is the configure.<module> name, NNNN is the patch apply order, e.g. 0000.

